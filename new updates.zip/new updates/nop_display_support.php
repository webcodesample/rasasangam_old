
<?php
    
    $result = "<h6>Number of Persons</h6>";

    for($i=2;$i<$_REQUEST['term'];$i++)
    {
        $result .= "<input type='radio' class='btn-check' name='no_of_person' id='no_of_person_".$i."' value='".$i."' onChange='show_date_options()' required>
<label class='btn btn-outline-success mb-2' for='no_of_person_".$i."'>".$i."</label>";
    }

    echo $result;
?>