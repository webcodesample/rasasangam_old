<?php
include_once("advance_functions.php");

showSlots($_REQUEST['arrivaldate']);

?>
