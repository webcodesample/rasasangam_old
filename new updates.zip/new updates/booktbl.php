<?php
include_once("advance_functions.php");

    if(isset($_REQUEST))
        print_r($_REQUEST);
?>

<div class="container mt-3">

        <h5 class="text-success">Table Booking Form</h5>
        <form method="post">
        <p>            
            <?php showNOPOptions(25); ?>
        </p>

        <p id="date_options">            
        </p>

        <p id="arrival_time_part">
        </p>

        <div id="customer_info" style="display:none">
            <input type="text" class="form-control p-2 mb-2" style="width:350px;" name="booking_name" placeholder="Enter Your Name" required>
            <input type="text" class="form-control p-2 mb-2" style="width:350px;" name="booking_email" placeholder="Enter Your Email" required>
            <input type="text" class="form-control p-2 mb-2" style="width:350px;" name="booking_mobile" placeholder="Enter Your Mobile No" required>
        
            <input type="hidden" name="page_name" value="booktbl">
            <input type="submit" class="btn btn-success" value="Book Table">
        </div>
        </form>

</div>