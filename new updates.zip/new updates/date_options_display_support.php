
<?php

    $result = "<h6>Select Date</h6>";

    $current_date = date('d');
    $current_month = date('m');
    $current_year = date('Y');
    $limit = $current_date + $_REQUEST['term'];

    for($i=$current_date;$i<$limit;$i++)
    {
        $date = date('D - d M',mktime(0,0,0,$current_month,$i,$current_year));
        $booking_date = date('d-m-Y',mktime(0,0,0,$current_month,$i,$current_year));

        $result .= "<input type='radio' class='btn-check' name='booking_date' id='booking_date_".$i."' value='".$booking_date."' onChange='show_at(this.value)' autocomplete='off' required>
<label class='btn btn-outline-success mb-2' for='booking_date_".$i."'>".$date."</label>";
    }

    echo $result;
?>