function setPage(pagename)
{
    document.getElementById("page_name").value = pagename;
    document.getElementById("siteform").submit();
}

function setPage_ajax(pagename)
{
    $.ajax({
        type: 'POST',
        url: "bodycontent.php",
        data: { page_name: pagename, },
        success: function (result) {
            $("#page").html(result);
        }
    });
}

function show_at(date)
{
    $.ajax({
        type: 'POST',
        url: "arrivaltime.php",
        data: { arrivaldate: date, },        
        success: function (result) {
            $("#arrival_time_part").html(result);
            if (result === "<h6 class='text-danger'>Booking Not Allowed for Today</h6>")
                $("#customer_info").hide();
        }
    });
}

function show_date_options()
{
    $("#booking_msg").hide();

    $.ajax({
        type: 'POST',
        url: "date_options.php",
        data: { },
        success: function (result) {
            $("#date_options").html(result);
        }
    });
}

function show_cust_info()
{
    $("#customer_info").show();
}