<div class="row mb-3 mt-2">
    <div class="col-md-5 p-3">
        <image src="Images/gallery.gif" width="90%" style="border-radius:0% 15% 0% 15%;">
    </div>
    <div class="col-md-7 pt-3">

        <div class="row">
            <div class="col-md-4">
                <image src="Images/Gallery/4.jpg" width="100%" style="border-radius:0%;">
            </div>
            <div class="col-md-4">
                <image src="Images/Gallery/5.jpg" width="100%" style="border-radius:0%;">
            </div>
            <div class="col-md-4">
                <image src="Images/Gallery/6.jpg" width="100%" style="border-radius:0%;">
            </div>
        </div>

        <div class="row">
            <div class="col-md-4">
                <image src="Images/Gallery/7.jpg" width="100%" style="border-radius:0%">
            </div>
            <div class="col-md-4">
                <image src="Images/Gallery/8.jpg" width="100%" style="border-radius:0%;">
            </div>
            <div class="col-md-4">
                <image src="Images/Gallery/9.jpg" width="100%" style="border-radius:0%;">
            </div>
        </div>

    </div>
</div>