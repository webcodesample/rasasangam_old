<div class='container mt-2' id="booking_msg"><center>
<?php
include_once("set_con.php");
if(PHP_VERSION<8.0)
{
 echo "You have a lower PHP Version : ".PHP_VERSION."<br> Please Upgrade PHP Version >8.0";
}
//print_r($_REQUEST);

    if(isset($_REQUEST) && $_REQUEST['cb_func']=="booking")
    {
        $date_parts = explode('-',$_REQUEST['booking_date']);
        $booking_date = mktime(0,0,0,$date_parts[1],$date_parts[0],$date_parts[2]);

        $arrival_time_hour = intdiv($_REQUEST['arrival_time'], 100);
        $arrival_time_minute = fmod($_REQUEST['arrival_time'], 100);

        $arrival_time = mktime($arrival_time_hour,$arrival_time_minute,0,$date_parts[1],$date_parts[0],$date_parts[2]);

        $slot_id = $arrival_time_hour - 11;

        $seat_limit_query = "Select maxseat From slot_details Where  id = '".$slot_id."'";
        $seat_limit_result = mysqli_query($conn,$seat_limit_query) or die('error in max_seat query '.mysqli_error().$seat_limit_query);
        $seat_limit = mysqli_fetch_assoc($seat_limit_result);
        $seat_limit['maxseat'];

        $booked_seat_query = "Select SUM(no_of_seats) AS total_booked_seats From booking Where date ='" . $booking_date ."' AND slot_id = '".$slot_id."'";
        $booked_seat_result = mysqli_query($conn,$booked_seat_query) or die('error in booked_seat query '.mysqli_error().$booked_seat_query);
        $booked_seat = mysqli_fetch_assoc($booked_seat_result);
        $booked_seat['total_booked_seats'];

        $available_seat = $seat_limit['maxseat']-$booked_seat['total_booked_seats'];

        if($_REQUEST['no_of_person']<=$available_seat)
        {
            $query="insert into booking set date = '".$booking_date."', arrival_time= '".$arrival_time."',slot_id = '".$slot_id."', no_of_seats = '".$_REQUEST['no_of_person']."', cust_name = '".$_REQUEST['booking_name']."', cust_email = '".$_REQUEST['booking_email']."', cust_mobile = '".$_REQUEST['booking_mobile']."'";
            $result= mysqli_query($conn,$query) or die('error in booking query '.mysqli_error().$query);

            echo "<h6 class='text-success'>Dear ".$_REQUEST['booking_name']." Thanks for Booking</h6>";
        }
        else
        {
            echo "<h6 class='text-danger'>Dear ".$_REQUEST['booking_name']." Sorry! All Seats are Booked</h6>";
        }
    }
        
?>
</center></div>

<div class="container mt-3">

        <h5 class="text-success">Table Booking Form</h5>
        <form method="post">
        <p>            
            <?php showNOPOptions(25); ?>
        </p>

        <p id="date_options">            
        </p>

        <p id="arrival_time_part">
        </p>

        <div id="customer_info" style="display:none">
            <input type="text" class="form-control p-2 mb-2" style="width:350px;" name="booking_name" placeholder="Enter Your Name" required>
            <input type="email" class="form-control p-2 mb-2" style="width:350px;" name="booking_email" placeholder="Enter Your Email" required>
            <input type="tel" class="form-control p-2 mb-2" style="width:350px;" name="booking_mobile" placeholder="Enter Your Mobile No" required>
        
            <input type="hidden" name="page_name" value="booktbl">
            <input type="hidden" name="cb_func" value="booking">
            <input type="submit" class="btn btn-success" value="Book Table">
        </div>
        </form>

</div>