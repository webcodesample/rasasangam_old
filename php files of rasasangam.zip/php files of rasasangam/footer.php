<div class="container">
  <footer class="pt-5">
    <div class="row">

    <div class="d-flex flex-column flex-sm-row justify-content-between py-1 my-1 border-top">
      <p>&copy; 2024 RasaSangam, All Rights Reserved.</p>
      <ul class="list-unstyled d-flex">
        <li class="ms-3"><a class="link-body-emphasis" href="https://www.instagram.com/rasasangam?igsh=MWFmajhvMmtiZmI1OA==" target="_blank"><i style="font-size:24px;" class="bi bi-instagram"></i></a></li>
      </ul>
    </div>
  </footer>
</div>