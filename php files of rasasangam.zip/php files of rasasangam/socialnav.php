    <nav class="navbar navbar-expand-sm navbgsocial justify-content-end">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="google.com"><i class="bi bi-facebook"></i></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="yahoo.com"><i class="bi bi-twitter"></i></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="amazon.in"><i class="bi bi-instagram"></i></a>
            </li>
        </ul>
    </nav>
