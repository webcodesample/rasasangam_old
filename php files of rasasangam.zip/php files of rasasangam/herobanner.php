<div>

<video width="100%" autoplay muted loop>
  <source src="Video/hero.mp4" type="video/mp4">
  <source src="Video/hero.ogg" type="video/ogg">
</video>

</div>