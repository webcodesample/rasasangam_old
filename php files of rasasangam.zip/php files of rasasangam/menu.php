<div class="row mb-1 mt-1">
    <div class="col-md-6 p-3">
        <image src="Images/Menu/1.jpg" width="100%" style="border-radius:2%;">
    </div>
    <div class="col-md-6 p-3">
        <image src="Images/Menu/2.jpg" width="100%" style="border-radius:2%;">
    </div>
</div>
<div class="row mb-1 mt-1">
    <div class="col-md-6 p-3">
        <image src="Images/Menu/3.jpg" width="100%" style="border-radius:2%;">
    </div>
    <div class="col-md-6 p-3">
        <image src="Images/Menu/4.jpg" width="100%" style="border-radius:2%;">
    </div>
</div>
<div class="row mb-1 mt-1">
    <div class="col-md-6 p-3">
        <image src="Images/Menu/5.jpg" width="100%" style="border-radius:2%;">
    </div>
    <div class="col-md-6 p-3">
        <image src="Images/Menu/6.jpg" width="100%" style="border-radius:2%;">
    </div>
</div>
<div class="row mb-1 mt-1">
    <div class="col-md-6 p-3">
        <image src="Images/Menu/7.jpg" width="100%" style="border-radius:2%;">
    </div>
    <div class="col-md-6 p-3">
        <image src="Images/Menu/8.jpg" width="100%" style="border-radius:2%;">
    </div>
</div>
<div class="row mb-1 mt-1">
    <div class="col-md-6 p-3">
        <image src="Images/Menu/9.jpg" width="100%" style="border-radius:2%;">
    </div>
    <div class="col-md-6 p-3">
        <image src="Images/Menu/10.jpg" width="100%" style="border-radius:2%;">
    </div>
</div>
<div class="row mb-1 mt-1">
    <div class="col-md-6 p-3">
        <image src="Images/Menu/11.jpg" width="100%" style="border-radius:2%;">
    </div>
    <div class="col-md-6 p-3">
        <image src="Images/Menu/12.jpg" width="100%" style="border-radius:2%;">
    </div>
</div>
