

<body style="background-color:white;">

<?php include_once("navbar.php"); include_once("bodycontent.php"); ?>

</body>

