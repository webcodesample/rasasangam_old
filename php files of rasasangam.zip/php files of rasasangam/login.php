<?php

include_once("head.php");

if(isset($_REQUEST['msg']))
echo "<div class='d-flex justify-content-center text-danger mt-5'><b>".$_REQUEST['msg']."</b></div>";
else
echo "<div class='d-flex justify-content-center text-success mt-5'><b>Please Enter Valid Credetials</b></div>";
?>

<div class="container border border-warning rounded" style="width:250px; padding:20px; margin-top:30px;">
<form method="post" action="login_check.php">

	<input type="text" name="username" class="form-control mb-2" style="width:200px;" placeholder="Enter Username" required>
	<input type="password" name="pswd" class="form-control mb-2" style="width:200px;" placeholder="Enter Password"required>
	<input type="submit" class="btn btn-sm btn-danger" value="Log-IN">

</form>
</div>
<?php include_once("footer.php"); ?>
