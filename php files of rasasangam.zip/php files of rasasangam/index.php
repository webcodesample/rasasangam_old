<!DOCTYPE html>
<html lang="en-US">

<?php

include_once("head.php");
include_once("body.php");
include_once("footer.php");

?>

</html>