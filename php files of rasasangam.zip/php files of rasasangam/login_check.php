<?php

if($_REQUEST['username'] == "admin" && $_REQUEST['pswd'] == "123456")
{
	session_start(); 

	$_SESSION['username']= $_REQUEST['username'];

	header("Location: viewbookings.php");
}
else 
{
	header("Location: login.php?msg=Sorry! Invalid Credentials");
	die();
}

?>