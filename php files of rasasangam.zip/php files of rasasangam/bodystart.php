

<body style="background-color:bisque;">

<?php 

//include_once("socialnav.php"); 
//include_once("topbanner.php"); 
include_once("navbar.php"); 
//include_once("herobanner.php"); 
//include_once("bodycontent.php"); 

?>

