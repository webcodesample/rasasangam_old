<?php
ob_start();
session_start();

include_once("head.php");
include_once("admin_body.php");
include_once("footer.php");

if($_SESSION['username'] == "")
{
	header("Location: login.php");
	die();
}


?>