<?php

$result = "Sorry! No Slot Available";

echo json_encode($result);

?>