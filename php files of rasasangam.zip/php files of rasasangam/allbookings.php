<div class="container">
  <h5>All Bookings for <span class="text-success"><?php echo date('d-M-Y l'); ?></span></h5>

<div class="row p-3 mb-3">
    <div class="border border-warning rounded col-md-2 m-2">
        <b>Arrival Time : 12:30 PM</b><br>
        No. of Seats : 2<br>
        Name : Guest<br>
        Mobile : 1234567890
    </div>
    <div class="border border-warning rounded col-md-2 m-2">
        <b>Arrival Time : 12:30 PM</b><br>
        No. of Seats : 2<br>
        Name : Guest<br>
        Mobile : 1234567890
    </div>
    <div class="border border-warning rounded col-md-2 m-2">
        <b>Arrival Time : 12:30 PM</b><br>
        No. of Seats : 2<br>
        Name : Guest<br>
        Mobile : 1234567890
    </div>
    <div class="border border-warning rounded col-md-2 m-2">
        <b>Arrival Time : 12:30 PM</b><br>
        No. of Seats : 2<br>
        Name : Guest<br>
        Mobile : 1234567890
    </div>
    <div class="border border-warning rounded col-md-2 m-2">
        <b>Arrival Time : 12:30 PM</b><br>
        No. of Seats : 2<br>
        Name : Guest<br>
        Mobile : 1234567890
    </div>
    <div class="border border-warning rounded col-md-2 m-2">
        <b>Arrival Time : 12:30 PM</b><br>
        No. of Seats : 2<br>
        Name : Guest<br>
        Mobile : 1234567890
    </div>
    <div class="border border-warning rounded col-md-2 m-2">
        <b>Arrival Time : 12:30 PM</b><br>
        No. of Seats : 2<br>
        Name : Guest<br>
        Mobile : 1234567890
    </div>
    <div class="border border-warning rounded col-md-2 m-2">
        <b>Arrival Time : 12:30 PM</b><br>
        No. of Seats : 2<br>
        Name : Guest<br>
        Mobile : 1234567890
    </div>
    <div class="border border-warning rounded col-md-2 m-2">
        <b>Arrival Time : 12:30 PM</b><br>
        No. of Seats : 2<br>
        Name : Guest<br>
        Mobile : 1234567890
    </div>
    <div class="border border-warning rounded col-md-2 m-2">
        <b>Arrival Time : 12:30 PM</b><br>
        No. of Seats : 2<br>
        Name : Guest<br>
        Mobile : 1234567890
    </div>
    <div class="border border-warning rounded col-md-2 m-2">
        <b>Arrival Time : 12:30 PM</b><br>
        No. of Seats : 2<br>
        Name : Guest<br>
        Mobile : 1234567890
    </div>
    <div class="border border-warning rounded col-md-2 m-2">
        <b>Arrival Time : 12:30 PM</b><br>
        No. of Seats : 2<br>
        Name : Guest<br>
        Mobile : 1234567890
    </div>
    <div class="border border-warning rounded col-md-2 m-2">
        <b>Arrival Time : 12:30 PM</b><br>
        No. of Seats : 2<br>
        Name : Guest<br>
        Mobile : 1234567890
    </div>
    <div class="border border-warning rounded col-md-2 m-2">
        <b>Arrival Time : 12:30 PM</b><br>
        No. of Seats : 2<br>
        Name : Guest<br>
        Mobile : 1234567890
    </div>
    <div class="border border-warning rounded col-md-2 m-2">
        <b>Arrival Time : 12:30 PM</b><br>
        No. of Seats : 2<br>
        Name : Guest<br>
        Mobile : 1234567890
    </div>
    <div class="border border-warning rounded col-md-2 m-2">
        <b>Arrival Time : 12:30 PM</b><br>
        No. of Seats : 2<br>
        Name : Guest<br>
        Mobile : 1234567890
    </div>
    <div class="border border-warning rounded col-md-2 m-2">
        <b>Arrival Time : 12:30 PM</b><br>
        No. of Seats : 2<br>
        Name : Guest<br>
        Mobile : 1234567890
    </div>
    <div class="border border-warning rounded col-md-2 m-2">
        <b>Arrival Time : 12:30 PM</b><br>
        No. of Seats : 2<br>
        Name : Guest<br>
        Mobile : 1234567890
    </div>
</div>
</div>