﻿<body style="background-color:white;">

<?php 
include_once("navbar_admin.php"); 
include_once("set_con.php");
?>

<div class="container">
  <h5>All Bookings for <span class="text-success">
  <?php //date_default_timezone_set("Asia/Kolkata"); 
  echo date('d-M-Y l'); ?>
  </span></h5>
  
<div class="row p-3 mb-3">

    <?php
    //echo strtotime('today');
        $view_bookings_query = "Select * From booking Where date = '".strtotime('today')."'";
        $view_bookings_result = mysqli_query($conn,$view_bookings_query) or die('error in view_bookings query '.mysqli_error().$view_bookings_query);

        while($row = mysqli_fetch_array($view_bookings_result))
        {
            echo "<div class='border border-warning rounded col-md-2 m-2'>
                    <b>Arrival Time : ".date('h:i A',$row['arrival_time'])."</b><br>
                    No. of Persons : ".$row['no_of_seats']."<br>
                    Name : ".$row['cust_name']."<br>
                    Mobile : ".$row['cust_mobile']."
                </div>";
            
        }

    ?>
</div>
</div>

</body>

