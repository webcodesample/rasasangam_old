<?php
include_once("set_fileurl.php");
include_once("advance_functions.php");

date_default_timezone_set("Asia/Kolkata");

$str = fgets(fopen(set_fileurl(),"r"));

if(setfileURL(set_fileurl().",".$str))
{
	$str_arr = explode(",",$str);

	$host = $str_arr[0];
	$user = $str_arr[1];
	$pass = $str_arr[2];
	$dbname = $str_arr[3];

	$conn = mysqli_connect($host, $user, $pass, $dbname) or die('error in connection'.mysqli_error());
	//$db = mysqli_select_db($dbname, $conn);
}
else 
{
	echo "Access Denied! <br> Database Host Connection Error";
	die();
}


?>