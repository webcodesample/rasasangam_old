    <div class="topbanner">
        <a href="https://google.com"><image src="Images/logo.jpg" class="logo"></image></a>
    </div>
